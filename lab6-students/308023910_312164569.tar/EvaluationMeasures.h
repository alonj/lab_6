//
// Created by annabel@staff.technion.ac.il on 5/9/17.
//

#ifndef LAB6_EVALUATIONMEASURES_H
#define LAB6_EVALUATIONMEASURES_H

#include "Point.h"
#include <vector>


class EvaluationMeasures {

public:
    static double accuracy(const std::vector<Point>& data);

};


#endif //LAB6_EVALUATIONMEASURES_H
